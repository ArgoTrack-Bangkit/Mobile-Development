package com.example.loginagro

data class UserData(
    val id: String? = null,
    val email: String? = null,
    val password: String? = null
)
